<!DOCTYPE html>

<html>
    <head>
        <title>Customer Registration | Edit</title> 
        <style>
            body {
                font-family: Arial, sans-serif;
                background-color: #f5f5f5;
                margin: 0;
                padding: 0;
            }
            h1{
                text-align: center;
            }
            
            form {
                width: 300px; 
                margin: 0 auto; 
                background-color: #fff; 
                border: 1px solid #ccc; 
                padding: 20px; 
                border-radius: 5px; 
                box-shadow: 0 0 10px rgba(0, 0, 0, 0.2);
            }
            input[type="submit"]:hover { 
                background-color: #0056b3;
            }
        </style>
    </head>
    <body>
        <form action="/edit/<?php echo e($student[0]->id); ?>" method="post"> 
            <?php echo csrf_field(); ?>
            <h1>Edit form</h1>
            <table>
                <tr>
                    <td>Name</td>
                    <td><input type="text" name="name" value="<?php echo e($student[0]->name); ?>" /></td>
                </tr>

                <tr>
                    <td>DOB</td>
                    <td><input type="date" name="dob" value="<?php echo e($student[0]->dob); ?>" /></td>
                </tr>

                <tr>
                    <td>Age</td>
                    <td><input type="text" name="age" value="<?php echo e($student[0]->age); ?>" /></td>
                </tr>
                
                <tr>
                    <td>Gender </td>
                    <td><input type="text" name="gender" value="<?php echo e($student[0]->gender); ?>" /></td>
                </tr>

                <tr>
                    <td>Email </td>
                    <td><input type="text" name="email" value="<?php echo e($student[0]->email); ?>" /></td>
                </tr>
                
                <tr>
                    <td>RollNo </td>
                    <td><input type="text" name="rollno" value="<?php echo e($student[0]->rollno); ?>" /></td>
                </tr>

                <tr>
                    <td>Phone </td>
                    <td><input type="number" name="phone" value="<?php echo e($student[0]->phone); ?>" /></td>
                </tr>
                <tr>
                    <td colspan="2">
                        <input type="submit" value="Update Student" />
                    </td>
                </tr>
             </table>
        </form>
    </body>
</html><?php /**PATH C:\Users\kitestudent\StudManagement\resources\views/student_edit.blade.php ENDPATH**/ ?>