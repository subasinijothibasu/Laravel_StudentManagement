<!DOCTYPE html>

<html>
    <head>
        <title>Customer Registration | Edit</title> 
        <style>
            body {
                font-family: Arial, sans-serif;
                background-color: #f5f5f5;
                margin: 0;
                padding: 0;
            }
            h1{
                text-align: center;
            }
            
            form {
                width: 300px; 
                margin: 0 auto; 
                background-color: #fff; 
                border: 1px solid #ccc; 
                padding: 20px; 
                border-radius: 5px; 
                box-shadow: 0 0 10px rgba(0, 0, 0, 0.2);
            }
            input[type="submit"]:hover { 
                background-color: #0056b3;
            }
        </style>
    </head>
    <body>
        <form action="/edit2/<?php echo e($course[0]->id); ?>" method="post"> 
            <?php echo csrf_field(); ?>
            <h1>Edit form</h1>
            <table>
                <tr>
                    <td>Course Name</td>
                    <td><input type="text" name="Course_name" value="<?php echo e($course[0]->Course_name); ?>" /></td>
                </tr>

                <tr>
                    <td>Course Code</td>
                    <td><input type="number" name="Course_code" value="<?php echo e($course[0]->Course_code); ?>" /></td>
                </tr>

                <tr>
                    <td>Department</td>
                    <td><input type="text" name="Department" value="<?php echo e($course[0]->Department); ?>" /></td>
                </tr>

                <tr>
                    <td colspan="2">
                        <input type="submit" value="Update Student" />
                    </td>
                </tr>
             </table>
        </form>
    </body>
</html><?php /**PATH C:\Users\kitestudent\StudManagement\resources\views/course_edit.blade.php ENDPATH**/ ?>