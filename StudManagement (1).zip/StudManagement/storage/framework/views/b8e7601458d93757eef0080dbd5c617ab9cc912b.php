<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>view course$course records</title>
    <style>
        body{
            font-size: 20px;
            background-color:#BCC8EC;
            
        }
        table{
            position: relative;
            top: 200px;
            border-collapse: collapse;
            margin: 0 auto;
            width: 200px;
            height: auto;
            border: 1px solid black;
        }
        th,td{
            padding: 10px;
            border: 10pxpx solid black;
        }
        tr:nth-child(even){
            background-color: dodgerblue;
        }
        tr:nth-child(even):hover{
            background-color: white;
        }
        </style>
</head>
<body>
    <table>
        <tr>
            <th>ID</th>
            <th>Course Name</th>
            <th>Course Code</th>
            <th>Department</th>
            <th>Edit</th>
            <th>Delete</th>
        </tr>
        <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($course->id); ?></td>
            <td><?php echo e($course->Course_name); ?></td>
            <td><?php echo e($course->Course_code); ?></td>
            <td><?php echo e($course->Department); ?></td>
            <td><a href="edit2/<?php echo e($course->id); ?>"> Edit</a></td>
            <td><a href="delete2/<?php echo e($course->id); ?>">Delete</a></td>
            
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
    <a href = "<?php echo e(route('course_insert')); ?>">
        <button class = "add-a-button">ADD COURSE </button>
    </a>
    <a href = "<?php echo e(route('LandingPage')); ?>">
        <button class = "add-a-button">GO BACK </button>
    </a>

</body>
</html><?php /**PATH C:\Users\kitestudent\StudManagement\resources\views/course_list.blade.php ENDPATH**/ ?>