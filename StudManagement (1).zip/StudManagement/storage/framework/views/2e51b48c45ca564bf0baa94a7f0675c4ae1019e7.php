<!DOCTYPE html>
<html>
<head>
    <title>Student Management System</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
        }
        header {
            background-color: #333;
            color: white;
            text-align: center;
            padding: 20px 0;
        }
        nav {
            background-color: #f4f4f4;
            text-align: center;
            padding: 10px 0;
        }
        nav a {
            text-decoration: none;
            color: #333;
            margin: 0 20px;
        }
        .container {
            max-width: 1200px;
            margin: auto;
            padding: 20px;
        }
        .section {
            margin-top: 30px;
            border-top: 1px solid #ccc;
            padding: 20px 0;
        }
        .section h2 {
            text-align: center;
        }
        .section ul {
            list-style: none;
            padding: 0;
            text-align: center;
        }
        .section ul li {
            display: inline-block;
            margin: 0 10px;
        }
        .section ul li a {
            text-decoration: none;
            color: #333;
        }
    </style>
</head>
<body>

<header>
    <h1>Welcome to Student Management System</h1>
</header>

<nav>
    <a href="/students">Students</a>
    <a href="#teachers">Teachers</a>
    <a href="#courses">Courses</a>
</nav>

<div class="container">
    <div id="students" class="section">
        <h2>Students</h2>
        <ul>
            <li><a href="/student">View Students</a></li>
            <li><a href="/insert_form">Add New Student</a></li>
            
        </ul>
    </div>

    <div id="teachers" class="section">
        <h2>Teachers</h2>
        <ul>
            <li><a href="/teacher">View Teachers</a></li>
            <li><a href="/teacher_insert">Add New Teacher</a></li>
            
        </ul>
    </div>

    <div id="courses" class="section">
        <h2>Courses</h2>
        <ul>
            <li><a href="/course">View Courses</a></li>
            <li><a href="/">Add New Course</a></li>
            
        </ul>
    </div>
</div>

</body>
</html>
<?php /**PATH C:\Users\kitestudent\StudManagement\resources\views/LandingPage.blade.php ENDPATH**/ ?>