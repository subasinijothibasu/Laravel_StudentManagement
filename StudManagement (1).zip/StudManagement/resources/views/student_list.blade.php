<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>view student records</title>
    <style>
        body{
            font-size: 20px;
            background-color:#BCC8EC;
            
        }
        table{
            position: relative;
            top: 200px;
            border-collapse: collapse;
            margin: 0 auto;
            width: 200px;
            height: auto;
            border: 1px solid black;
        }
        th,td{
            padding: 10px;
            border: 10pxpx solid black;
        }
        tr:nth-child(even){
            background-color: dodgerblue;
        }
        tr:nth-child(even):hover{
            background-color: white;
        }
        </style>
</head>
<body>
    <table>
        <tr>
            <th>ID</th>
            <th>Name</th>
            <th>DOB</th>
            <th>Age</th>
            <th>Gender</th>
            <th>Email</th>
            <th>Roll No</th>
            <th>Phone</th>
            <th>Edit</th>
            <th>Delete</th>
        </tr>
        @foreach ($students as $student)
        <tr>
            <td>{{ $student->id }}</td>
            <td>{{ $student->name }}</td>
            <td>{{ $student->dob }}</td>
            <td>{{ $student->age}}</td>
            <td>{{ $student->gender }}</td>
            <td>{{ $student->email }}</td>
            <td>{{ $student->rollno }}</td>
            <td>{{ $student->phone }}</td>
            <td><a href="edit/{{ $student->id }}"> Edit</a></td>
            <td><a href="delete/{{ $student->id }}">Delete</a></td>
            
        </tr>
        @endforeach
    </table>
    <a href = "{{ route('insert_form') }}">
        <button class = "add-a-button">ADD STUDENT </button>
    </a>
    <a href = "{{ route('LandingPage') }}">
        <button class = "add-a-button">GO BACK </button>
    </a>

</body>
</html>