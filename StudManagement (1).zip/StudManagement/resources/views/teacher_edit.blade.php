<!DOCTYPE html>

<html>
    <head>
        <title>Customer Registration | Edit</title> 
        <style>
            body {
                font-family: Arial, sans-serif;
                background-color: #f5f5f5;
                margin: 0;
                padding: 0;
            }
            h1{
                text-align: center;
            }
            
            form {
                width: 300px; 
                margin: 0 auto; 
                background-color: #fff; 
                border: 1px solid #ccc; 
                padding: 20px; 
                border-radius: 5px; 
                box-shadow: 0 0 10px rgba(0, 0, 0, 0.2);
            }
            input[type="submit"]:hover { 
                background-color: #0056b3;
            }
        </style>
    </head>
    <body>
        <form action="/edit1/{{ $teacher[0]->id }}" method="post"> 
            @csrf
            <h1>Edit form</h1>
            <table>
                <tr>
                    <td>Name</td>
                    <td><input type="text" name="name" value="{{ $teacher[0]->name }}" /></td>
                </tr>

                <tr>
                    <td>DOB</td>
                    <td><input type="date" name="dob" value="{{ $teacher[0]->dob }}" /></td>
                </tr>

                <tr>
                    <td>Email</td>
                    <td><input type="text" name="email" value="{{ $teacher[0]->email }}" /></td>
                </tr>
                
                <tr>
                    <td>Age </td>
                    <td><input type="text" name="age" value="{{ $teacher[0]->age }}" /></td>
                </tr>

                <tr>
                    <td>Gender </td>
                    <td><input type="text" name="gender" value="{{ $teacher[0]->gender }}" /></td>
                </tr>
                
                <tr>
                    <td>Phone </td>
                    <td><input type="number" name="phone" value="{{ $teacher[0]->phone }}" /></td>
                </tr>

                <tr>
                    <td>Qualification </td>
                    <td><input type="text" name="Qualufication" value="{{ $teacher[0]->Qualufication }}" /></td>
                </tr>

                <tr>
                    <td>DOJ </td>
                    <td><input type="date" name="doj" value="{{ $teacher[0]->doj}}" /></td>
                </tr>
            

                <tr>
                    <td colspan="2">
                        <input type="submit" value="Update Teacher" />
                    </td>
                </tr>
             </table>
        </form>
    </body>
</html>