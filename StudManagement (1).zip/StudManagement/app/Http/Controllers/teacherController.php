<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class teacherController extends Controller
{
    public function teacher_insert(){
        return view('teacher_insert');
    }
    public function insert1(Request $request){
        $name = $request->input('name');
        $dob = $request->input('dob');
        $email = $request->input('email');
        $age = $request->input('age');
        $gender = $request->input('gender');
        $phone = $request->input('phone');
        $Qualufication = $request->input('Qualufication');
        $doj = $request->input('doj');
        
        
        
        DB::insert("insert into teacher(name,dob,email,age,gender,phone,Qualufication,doj) values(?, ?, ?, ?, ?, ?, ?, ?)", [$name,$dob,$email,$age,$gender,$phone,$Qualufication,$doj]);
        return 'Record inserted successfully!  <a href="/view-records-teacher">Click here to go back</a>';
    }

    public function teacher_list(){
        $teachers= DB::select("select * from teacher");
        return view('teacher_list',['teachers'=>$teachers]);
    }
    public function edit1($id){
        $teacher = DB::select("select * from teacher where id=?", [$id]);
        return view('teacher_edit',['teacher'=>$teacher]);
    }

    public function update1(Request $request,$id){
        $name = $request->input('name');
        $dob = $request->input('dob');
        $email = $request->input('email');
        $age = $request->input('age');
        $gender = $request->input('gender');
        $phone = $request->input('phone');
        $Qualufication = $request->input('Qualufication');
        $doj = $request->input('doj');
        DB::update("update teacher set name=?,dob=?,email=?,age=?,gender=?,phone=?,Qualufication=?,doj=? where id=?",[$name,$dob,$email,$age,$gender,$phone,$Qualufication,$doj,$id]);
        return 'Record updated successfully!  <a href="/view-records-teacher">Click here to go back</a>';
       
    }
    
    public function delete1($id){
        DB::delete("delete from teacher where id=?",[$id]);
        return 'Record deleted successfully!  <a href="/view-records-teacher">Click here to go back</a>';
    }
}
