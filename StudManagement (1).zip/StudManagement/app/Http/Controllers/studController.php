<?php

namespace App\Http\Controllers;
use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;

class studController extends Controller
{
    public function insert_form(){
        return view('insert_form');
    }
    public function insert(Request $request){
        $name = $request->input('name');
        $dob = $request->input('dob');
        $age = $request->input('age');
        $gender = $request->input('gender');
        $email = $request->input('email');
        $rollno = $request->input('rollno');
        $phone = $request->input('phone');
        
        DB::insert("insert into student(name,dob,age,gender,email,rollno,phone) values(?, ?, ?, ?, ?, ?,?)", [$name,$dob,$age,$gender,$email,$rollno,$phone]);
        return 'Record inserted successfully!  <a href="/view-records-student">Click here to go back</a>';
    }

    public function student_list(){
        $students= DB::select("select * from student");
        return view('student_list',['students'=>$students]);
    }
    public function edit($id){
        $student = DB::select("select * from student where id=?", [$id]);
        return view('student_edit',['student'=>$student]);
    }

    public function update(Request $request,$id){
        $name = $request->input('name');
        $dob = $request->input('dob');
        $age = $request->input('age');
        $gender = $request->input('gender');
        $email = $request->input('email');
        $rollno = $request->input('rollno');
        $phone = $request->input('phone');
        DB::update("update student set name=?,dob=?,age=?,gender=?,email=?,rollno=?,phone=? where id=?",[$name,$dob,$age,$gender,$email,$rollno,$phone,$id]);
        return 'Record updated successfully!  <a href="/view-records-student">Click here to go back</a>';
       
    }
    
    public function delete($id){
        DB::delete("delete from student where id=?",[$id]);
        return 'Record deleted successfully!  <a href="/view-records-student">Click here to go back</a>';
    }
}
