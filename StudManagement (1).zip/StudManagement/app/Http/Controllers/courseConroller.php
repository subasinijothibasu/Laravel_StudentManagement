<?php

namespace App\Http\Controllers;
use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;

class courseConroller extends Controller
{
    public function  course_insert(){
        return view('course_insert');
    }
    public function insert2(Request $request){
        $Course_name = $request->input('Course_name');
        $Course_code = $request->input('Course_code');
        $Department = $request->input('Department');

        DB::insert("insert into course(Course_name,Course_code,Department) values(?, ?, ?)", [$Course_name,$Course_code,$Department]);
        return 'Record inserted successfully!  <a href="/view-records-course">Click here to go back</a>';
    }

    public function course_list(){
        $courses= DB::select("select * from course");
        return view('course_list',['courses'=>$courses]);
    }
    public function edit2($id){
        $course = DB::select("select * from course where id=?", [$id]);
        return view('course_edit',['course'=>$course]);
    }

    public function update2(Request $request,$id){
        $Course_name = $request->input('Course_name');
        $Course_code = $request->input('Course_code');
        $Department = $request->input('Department');
        DB::update("update course set Course_name=?,Course_code=?,Department=? where id=?",[$Course_name,$Course_code,$Department,$id]);
        return 'Record updated successfully!  <a href="/view-records-course">Click here to go back</a>';
       
    }
    
    public function delete2($id){
        DB::delete("delete from course where id=?",[$id]);
        return 'Record deleted successfully!  <a href="/view-records-course">Click here to go back</a>';
    }
}
