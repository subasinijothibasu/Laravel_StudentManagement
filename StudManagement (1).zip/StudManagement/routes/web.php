<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\studController;
use App\Http\Controllers\teacherController;
use App\Http\Controllers\courseConroller;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('LandingPage');
});

//Student fields

Route::get('/student', [App\Http\Controllers\studController::class, 'student_list']);

Route::get('/', [studController::class, 'insert_form']);
Route::post('/create', [studController::class, 'insert']);

Route::get('insert_form', [App\Http\Controllers\studController::class, 'insert_form'])->name('insert_form');

Route::get('/LandingPage', function(){
    return view('LandingPage');
})->name('LandingPage');

Route::get('view-records-student', [studController::class, 'student_list']);

Route::get('edit/{id}', [studController::class, 'edit']);
Route::post('edit/{id}', [studController::class, 'update']);

Route::get('delete/{id}', [studController::class, 'delete']);

//Teacher fields

Route::get('/teacher', [App\Http\Controllers\teacherController::class, 'teacher_list']);

Route::get('/', [teacherController::class, 'teacher_insert']);
Route::post('/create1', [teacherController::class, 'insert1']);

Route::get('teacher_insert', [App\Http\Controllers\teacherController::class, 'teacher_insert'])->name('teacher_insert');



Route::get('view-records-teacher', [teacherController::class, 'teacher_list']);

Route::get('edit1/{id}', [teacherController::class, 'edit1']);
Route::post('edit1/{id}', [teacherController::class, 'update1']);

Route::get('delete1/{id}', [teacherController::class, 'delete1']);


//Course fields

Route::get('/course', [App\Http\Controllers\courseConroller::class, 'course_list']);

Route::get('/', [courseConroller::class, 'course_insert']);
Route::post('/create2', [courseConroller::class, 'insert2']);

Route::get('course_insert', [App\Http\Controllers\courseConroller::class, 'course_insert'])->name('course_insert');



Route::get('view-records-course', [courseConroller::class, 'course_list']);

Route::get('edit2/{id}', [courseConroller::class, 'edit2']);
Route::post('edit2/{id}', [courseConroller::class, 'update2']);

Route::get('delete2/{id}', [courseConroller::class, 'delete2']);

